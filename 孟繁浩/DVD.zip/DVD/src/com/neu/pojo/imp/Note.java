package com.neu.pojo.imp;

public class Note
{
    private String note;
    public Note(String note)
    {
        this.note=note;
    }
    public String toString()
    {
        return this.note;
    }
}
