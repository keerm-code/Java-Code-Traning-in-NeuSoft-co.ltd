package com.neu.pojo;

public interface ICd {
    
}
