package com.neu.bike.pojo;

import com.neu.bike.pojo.impl.Bike;



public  interface IPerson{
    enum TYPE {
        MANAGER, SERVICER, SUPPLIER, USER

    }
}