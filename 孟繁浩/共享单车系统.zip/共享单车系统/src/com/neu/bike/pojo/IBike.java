package com.neu.bike.pojo;

public interface IBike {
}
