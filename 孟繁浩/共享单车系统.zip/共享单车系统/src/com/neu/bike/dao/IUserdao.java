package com.neu.bike.dao;

public interface IUserdao {
}
