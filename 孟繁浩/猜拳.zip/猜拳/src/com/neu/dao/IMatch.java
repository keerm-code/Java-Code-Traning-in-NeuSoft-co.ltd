package neu.dao;

public interface IMatch {
    
}
