package neu.dao;

import neu.pojo.imp.*;
import neu.pojo.*;

public class Match {
    User human_player=new User();
    Bot bot=new Bot();
}
