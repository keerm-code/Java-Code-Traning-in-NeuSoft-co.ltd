package neu.service;

import neu.pojo.imp.*;

public interface IService {
    int judge_who_win(User user,Bot bot);
    
}
