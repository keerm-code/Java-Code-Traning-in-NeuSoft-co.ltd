package neu.pojo.imp;

public enum Fist {
    SHEARS,ROCK,CLOTHES;
}
