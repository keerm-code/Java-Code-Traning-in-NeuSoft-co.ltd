package neu.pojo;

import neu.pojo.imp.*;

public interface IPlayer {
    void bet(String fist) throws Exception;
}
